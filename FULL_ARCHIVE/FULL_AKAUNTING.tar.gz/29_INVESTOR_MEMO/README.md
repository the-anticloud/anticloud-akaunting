# 29 Investor Memo

**Project:** AKAUNTING
**Upstream:** https://github.com/akaunting/akaunting

Content specific to AKAUNTING in category CONSULTANCY.
