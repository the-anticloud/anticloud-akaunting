# 01 Investor Package

**Project:** AKAUNTING
**Upstream:** https://github.com/akaunting/akaunting

Content specific to AKAUNTING in category CONSULTANCY.
